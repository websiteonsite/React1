import React from 'react';
import Cart from './Cart';

function App() {
  return (
    <div className="App">
      <Cart />
    </div>
  );
}

export default App;
