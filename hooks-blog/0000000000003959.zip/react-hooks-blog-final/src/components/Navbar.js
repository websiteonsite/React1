function Navbar() {
  return <div className="">Navbar</div>;
}

export default Navbar;
