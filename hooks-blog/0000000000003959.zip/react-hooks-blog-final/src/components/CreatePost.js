function CreatePost() {
  return <div className="">CreatePost</div>;
}

export default CreatePost;
