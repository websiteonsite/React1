function App() {
  return (
    <div className="App">
      Starting React Blog
    </div>
  );
}

export default App;
