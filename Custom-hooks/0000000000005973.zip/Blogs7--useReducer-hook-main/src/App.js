import Blog from "./Components/Blog";

function App() {
  return (
    <>
      <Blog />
    </>
  );
}

export default App;
