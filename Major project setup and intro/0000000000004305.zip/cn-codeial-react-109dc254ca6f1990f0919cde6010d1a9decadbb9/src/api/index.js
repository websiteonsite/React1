const customFetch = () => {};

const getPosts = (page, limit) => {
  return customFetch();
};
