import React from 'react';
import CartItem from './CartItem';

function App() {
  return (
    <div className="App">
      <CartItem />
    </div>
  );
}

export default App;
